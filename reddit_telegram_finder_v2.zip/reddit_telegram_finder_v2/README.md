# Reddit → Telegram job finder

This version checks every 10 minutes and sends matching Reddit posts to your Telegram bot with 3 reply drafts.

## What it does
- checks `r/forhire`, `r/slavelabour`, and `r/DoneDirtCheap`
- looks for keywords like `bot`, `script`, `automation`, `scrape`, `python`, and `website`
- sends the post link + 3 reply drafts to Telegram
- saves seen post IDs so you don't get duplicate alerts

## What it does not do
- it does **not** auto-reply on Reddit
- you still open the post and send the message yourself

## Easiest iPhone setup
1. In Safari, go to `github.com` and sign in.
2. Tap the `aA` button in the address bar and choose **Request Desktop Website** if needed.
3. Tap the **+** menu in the top-right of the GitHub website.
4. Tap **New repository**.
5. Name it `job-finder-bot` and create it.
6. Upload these files.
7. In the repo, open **Settings → Secrets and variables → Actions**.
8. Add `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID`.
9. Open **Actions**, enable workflows if asked, and run **Reddit Telegram Finder** once.

## Notes
- The schedule is set for minutes `7,17,27,37,47,57` each hour.
- GitHub Actions schedules can be delayed sometimes, so it may not hit the exact minute every time.
