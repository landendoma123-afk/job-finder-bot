import json
import os
import re
import textwrap
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import quote

import feedparser
import requests

SUBREDDITS = [s.strip() for s in os.getenv("SUBREDDITS", "forhire,slavelabour,DoneDirtCheap").split(",") if s.strip()]
KEYWORDS = [k.strip().lower() for k in os.getenv(
    "KEYWORDS",
    "bot,script,automation,automate,scrape,scraper,python,website,web app,api,tool,telegram,discord"
).split(",") if k.strip()]
NEGATIVE_KEYWORDS = [k.strip().lower() for k in os.getenv(
    "NEGATIVE_KEYWORDS",
    "nsfw,adult,gambling,crypto pump,casino"
).split(",") if k.strip()]
MAX_PER_SUB = int(os.getenv("MAX_PER_SUB", "20"))
STATE_FILE = Path("data/seen_posts.json")
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

SERVICE_MAP = {
    "scrape": "scrapers and data collection tools",
    "scraper": "scrapers and data collection tools",
    "automation": "automation workflows",
    "automate": "automation workflows",
    "bot": "bots and small automations",
    "script": "small scripts and one-off tools",
    "python": "Python tools",
    "website": "simple websites and web tools",
    "web app": "small web apps",
    "api": "API integrations",
    "telegram": "Telegram bots",
    "discord": "Discord bots",
}


def load_seen():
    if not STATE_FILE.exists():
        return []
    try:
        return json.loads(STATE_FILE.read_text())
    except Exception:
        return []


def save_seen(seen):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(seen[-500:], indent=2))


def normalize_whitespace(text: str) -> str:
    return re.sub(r"\s+", " ", text or "").strip()


def service_hint(matched: list[str]) -> str:
    for term in matched:
        if term in SERVICE_MAP:
            return SERVICE_MAP[term]
    return "small custom tools"


def make_drafts(title: str, matched: list[str]) -> list[str]:
    service = service_hint(matched)
    topic = title.strip().rstrip(".?!")
    return [
        (
            f"Hey — I can help with this. I build {service} and this sounds like something I could turn around pretty quickly. "
            f"If you're still hiring, send me the exact scope, budget, and deadline and I’ll tell you fast if I’m a fit."
        ),
        (
            f"Saw your post about \"{topic}\". I’ve built similar {service} before and can usually move fast on small jobs. "
            f"If you want, message me the details and your timeline and I can give you a quick plan + price."
        ),
        (
            f"I might be able to knock this out for you. I focus on {service}, and I’m good with quick-turn work. "
            f"If the job is still open, send over the requirements and budget and I’ll reply with what I’d do."
        ),
    ]


def rss_url(subreddit: str) -> str:
    return f"https://www.reddit.com/r/{subreddit}/new/.rss"


def post_matches(text: str):
    low = text.lower()
    if any(bad in low for bad in NEGATIVE_KEYWORDS):
        return []
    return [kw for kw in KEYWORDS if kw in low]


def parse_entry(subreddit: str, entry: dict):
    title = normalize_whitespace(entry.get("title", ""))
    summary = normalize_whitespace(entry.get("summary", ""))
    link = entry.get("link", "")
    post_id = link.rstrip("/").split("/")[-1] or title
    text = f"{title} {summary}"
    matched = post_matches(text)
    if not matched:
        return None
    drafts = make_drafts(title, matched)
    return {
        "id": post_id,
        "subreddit": subreddit,
        "title": title,
        "summary": summary[:600],
        "url": link,
        "matched": matched,
        "drafts": drafts,
        "created": entry.get("published", "")
    }


def fetch_matches():
    seen = load_seen()
    seen_set = set(seen)
    new_seen = list(seen)
    matches = []

    headers = {"User-Agent": "Mozilla/5.0 job-finder-by-request"}
    for subreddit in SUBREDDITS:
        response = requests.get(rss_url(subreddit), headers=headers, timeout=20)
        response.raise_for_status()
        feed = feedparser.parse(response.text)
        count = 0
        for entry in feed.entries:
            if count >= MAX_PER_SUB:
                break
            parsed = parse_entry(subreddit, entry)
            if not parsed:
                continue
            count += 1
            if parsed["id"] in seen_set:
                continue
            matches.append(parsed)
            new_seen.append(parsed["id"])
            seen_set.add(parsed["id"])

    save_seen(new_seen)
    return matches


def telegram_send(text: str):
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        raise RuntimeError("Missing TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID")

    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    resp = requests.post(
        url,
        json={
            "chat_id": TELEGRAM_CHAT_ID,
            "text": text,
            "disable_web_page_preview": True,
        },
        timeout=20,
    )
    resp.raise_for_status()


def format_message(match: dict) -> str:
    dm_text = quote(match['drafts'][0])
    drafts_block = "\n\n".join([f"Version {i+1}:\n{draft}" for i, draft in enumerate(match["drafts"])])
    return textwrap.dedent(
        f"""
        New Reddit lead
        Subreddit: r/{match['subreddit']}
        Matched: {', '.join(match['matched'])}
        Title: {match['title']}
        Link: {match['url']}

        Reply drafts:
        {drafts_block}

        Optional DM link:
        https://www.reddit.com/message/compose/?subject={quote('Regarding your post')}&message={dm_text}
        """
    ).strip()


def main():
    matches = fetch_matches()
    print(f"Found {len(matches)} new matches at {datetime.now(timezone.utc).isoformat()}")
    for match in matches[:10]:
        msg = format_message(match)
        print("-" * 60)
        print(msg)
        if TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID:
            telegram_send(msg)


if __name__ == "__main__":
    main()
